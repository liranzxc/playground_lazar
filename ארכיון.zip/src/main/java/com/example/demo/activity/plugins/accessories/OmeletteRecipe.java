package com.example.demo.activity.plugins.accessories;

import java.util.List;

public class OmeletteRecipe {
	private String eggSize;
	
	public OmeletteRecipe() {
	}
	
	public String getEggSize() {
		return eggSize;
	}

	public void setEggSize(String eggSize) {
		this.eggSize = eggSize;
	}


	
	
}
