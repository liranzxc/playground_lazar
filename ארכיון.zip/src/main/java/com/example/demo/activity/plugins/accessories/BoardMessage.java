package com.example.demo.activity.plugins.accessories;

public class BoardMessage {
	private String poster;
	private String message;
	
	public BoardMessage() {

	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
