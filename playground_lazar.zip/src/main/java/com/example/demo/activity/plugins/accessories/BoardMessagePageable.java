package com.example.demo.activity.plugins.accessories;

public class BoardMessagePageable {
	private int page;
	private int size;
	
	public BoardMessagePageable() {
		this.size = 5;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	
}
