package com.example.demo.activity.plugins;

import com.example.demo.activity.ActivityEntity;

public interface PlaygroundPlugin {
	public Object invokeOperation(ActivityEntity et);
}
