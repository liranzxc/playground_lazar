package com.example.demo.activity.plugins.accessories;


public class OmeletteRecipe {
	private String eggSize;
	
	public OmeletteRecipe() {
	}
	
	public String getEggSize() {
		return eggSize;
	}

	public void setEggSize(String eggSize) {
		this.eggSize = eggSize;
	}


	
	
}
