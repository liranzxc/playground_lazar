package com.example.demo.element.exceptions;

public class InvalidAttributeNameException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public InvalidAttributeNameException(String message) {
		super(message);
	}

}
