package com.example.demo.element.exceptions;

public class InvalidDistanceValueException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidDistanceValueException(String string) {
		super(string);
	}
}
