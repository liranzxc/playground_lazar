package com.example.demo.user.exceptions;

public class InvalidRoleException extends Exception {

	public InvalidRoleException(String string) {
		super();
	}

	private static final long serialVersionUID = -2866513624385462225L;

}
