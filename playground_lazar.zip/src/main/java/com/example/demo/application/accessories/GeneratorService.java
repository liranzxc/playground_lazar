package com.example.demo.application.accessories;

public interface GeneratorService {

	public String generateValidationCode();

	//used for test
	public void stopConsoleForCode();
}
